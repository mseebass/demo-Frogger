package com.example.michael.opengles20frogger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.MotionEvent;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;


public class MainActivity extends Activity {

    private GLSurfaceView mSurfaceView;
    private FroggerRenderer mRenderer;
    private MediaPlayer mMediaPlayer;
    private SoundPool mSoundPool;
    private int[] mSoundIds = new int[2];

    public static final String ACTION_SHOW_DIALOG = "ACTION_SHOW_DIALOG";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSurfaceView = new FroggerSurfaceView(this);
        setContentView(mSurfaceView);
        registerReceiver(new FroggerBroadcastReceiver(), new IntentFilter(ACTION_SHOW_DIALOG));
        mMediaPlayer = MediaPlayer.create(this, R.raw.backsound);
        mMediaPlayer.setLooping(true);
        mMediaPlayer.setVolume(0.7f, 0.7f);
        mMediaPlayer.start();
        mSoundPool = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);
        mSoundIds[0] = mSoundPool.load(this, R.raw.jump, 1);
        mSoundIds[1] = mSoundPool.load(this, R.raw.carhorn, 2);
    }

    @Override
    protected void onStop() {
        if (mMediaPlayer != null) {
            mMediaPlayer.stop();
        }
        super.onStop();
    }

    public GLSurfaceView getSurfaceView() {
        return mSurfaceView;
    }

    private class FroggerSurfaceView extends GLSurfaceView {

        private MainActivity mMainActivity;

        private FroggerSurfaceView(MainActivity activity) {
            super(activity);
            this.mMainActivity = activity;
            setEGLContextClientVersion(2);
            mRenderer = new FroggerRenderer(mMainActivity);
            setRenderer(mRenderer);
            setRenderMode(RENDERMODE_CONTINUOUSLY);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    mRenderer.mFrog.setJumping(true);
                    mRenderer.mFrog.setImage(1);
                    mRenderer.mFrog.move(0.2f);
                    mSoundPool.play(mSoundIds[0], 1.0f, 1.0f, 1, 0, 1.0f);
                    break;
                case MotionEvent.ACTION_UP:
                    mRenderer.mFrog.setJumping(false);
                    mRenderer.mFrog.setImage(0);
                    mRenderer.mFrog.move(0.07f);
                    break;
            }

            return true;
        }
    }

    public class FroggerRenderer implements GLSurfaceView.Renderer {

        private MainActivity mMainActivity;
        private Level mLevel;
        private Frog mFrog;
        private Cars mCars;
        private float mSurfaceAspectRatio = 1;

        private FroggerRenderer(MainActivity activity) {
            this.mMainActivity = activity;
            mLevel = new Level(activity);
            mFrog = new Frog(activity);
            mCars = new Cars(activity);
        }

        @Override
        public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {
            mLevel.onSurfaceCreated(eglConfig);
            mFrog.onSurfaceCreated(eglConfig);
            mCars.onSurfaceCreated(eglConfig);
        }

        @Override
        public void onSurfaceChanged(GL10 gl10, int width, int height) {
            GLES20.glViewport(0, 0, width, height); // nur zur Sicherheit, eigentlich nicht nötig
            mLevel.onSurfaceChanged(width, height);
            mFrog.onSurfaceChanged(width, height);
            mCars.onSurfaceChanged(width, height);
            mSurfaceAspectRatio = (float) width / (float) height;
        }

        @Override
        public void onDrawFrame(GL10 gl10) {
            mLevel.onDrawFrame();
            mFrog.onDrawFrame();
            mCars.onDrawFrame();
        }

        public float getSurfaceAspectRatio() {
            return mSurfaceAspectRatio;
        }

        public Frog getFrog() {
            return mFrog;
        }

        public Level getLevel() {
            return mLevel;
        }

        public Cars getCars() {
            return mCars;
        }
    }

    public FroggerRenderer getRenderer() {
        return mRenderer;
    }


    public class FroggerBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(ACTION_SHOW_DIALOG)) {
                showAlert();
            }
        }
    }

    public void showAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Du hast " + (int) mRenderer.getLevel().getPoints() + "Punkte erreicht. Neues Spiel?");
        builder.setCancelable(false);
        builder.setPositiveButton("Ja", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mRenderer.getFrog().reset();
                mRenderer.getLevel().setLifes(3);
                mRenderer.getLevel().setPoints(0.0f);
                mRenderer.getLevel().addPoints(0.0f);
                mRenderer.getCars().setSpeed(1.0f);
                mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
                mRenderer.getCars().setLastMoveTime(System.nanoTime());
            }
        });
        builder.setNegativeButton("Nein", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                System.exit(0);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public SoundPool getSoundPool() {
        return mSoundPool;
    }

    public int getSoundId(int pos) {
        return mSoundIds[pos];
    }
}