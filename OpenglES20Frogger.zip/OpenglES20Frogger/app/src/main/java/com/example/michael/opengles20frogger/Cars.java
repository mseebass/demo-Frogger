package com.example.michael.opengles20frogger;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.Random;

import javax.microedition.khronos.egl.EGLConfig;

/**
 * Created by Michael on 07.11.2014.
 */
public class Cars {

    private MainActivity mMainActivity;
    private int mCarShader;
    private Bitmap[] mCarImages = new Bitmap[5];
    private Car[] mCars = new Car[4];
    private long mLastMoveTime;
    private float[] mLaneSpeedFactor = { 1,.0f, 1.5f, 1.6f, 1.1f };
    private Random mRandom = new Random();
    private int mPositionHandle, mTextureCoordHandle;
    private float mSpeed = 1.0f;

    private static String sVertexShaderCode =
            "attribute vec4 vPosition;\n" +
                    "attribute vec2 vTextureCoord;\n" +
                    "varying vec2 fTextureCoord;\n" +
                    "void main() {\n" +
                    "gl_Position = vPosition;\n" +
                    "fTextureCoord = vTextureCoord;\n" +
                    "}\n";

    private static String sFragmentShaderCode =
            "precision mediump float;\n" +
                    "varying vec2 fTextureCoord;\n" +
                    "uniform sampler2D fTexture;\n" +
                    "void main() {\n" +
                    "gl_FragColor = texture2D(fTexture, fTextureCoord);\n" +
                    "}\n";


    public Cars(MainActivity activity) {
        this.mMainActivity = activity;
    }

    public void onSurfaceCreated(EGLConfig eglConfig) {
        int vertexShader = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);
        GLES20.glShaderSource(vertexShader, sVertexShaderCode);
        GLES20.glCompileShader(vertexShader);

        int fragmentShader = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);
        GLES20.glShaderSource(fragmentShader, sFragmentShaderCode);
        GLES20.glCompileShader(fragmentShader);

        mCarShader = GLES20.glCreateProgram();
        GLES20.glAttachShader(mCarShader, vertexShader);
        GLES20.glAttachShader(mCarShader, fragmentShader);
        GLES20.glLinkProgram(mCarShader);

        mCarImages[0] = BitmapFactory.decodeResource(mMainActivity.getResources(), R.drawable.car1);
        mCarImages[1] = BitmapFactory.decodeResource(mMainActivity.getResources(), R.drawable.car2);
        mCarImages[2] = BitmapFactory.decodeResource(mMainActivity.getResources(), R.drawable.car3);
        mCarImages[3] = BitmapFactory.decodeResource(mMainActivity.getResources(), R.drawable.car4);
        mCarImages[4] = BitmapFactory.decodeResource(mMainActivity.getResources(), R.drawable.car5);
    }

    public void onSurfaceChanged(int width, int height) {
        for (int carNr =0; carNr < 4; carNr++) {
            mCars[carNr] = new Car(mCarImages[carNr], mCarShader, carNr);
        }
        mLastMoveTime = System.nanoTime();
    }

    public void onDrawFrame() {
        long timeDiff = System.nanoTime() - mLastMoveTime;
        mLastMoveTime = System.nanoTime();
        for (int carNr =0; carNr < 4; carNr++) {
            if (mCars[carNr].mVertices[2] * mCars[carNr].mCarMoveDirection > 1.0f) {
                mCars[carNr] = new Car(mCarImages[mRandom.nextInt(5)], mCarShader, carNr);
                //mCars[carNr] = new Car(mCarImages[3], mCarShader, carNr); TODO
            }
            mCars[carNr].move((float) timeDiff / 5000000000f * mLaneSpeedFactor[carNr] * mSpeed);
            mCars[carNr].draw();
        }
    }

    public float getSpeed() {
        return mSpeed;
    }

    public void setSpeed(float speed) {
        mSpeed = speed;
    }

    public void setLastMoveTime(long lastMoveTime) {
        mLastMoveTime = lastMoveTime;
    }

    public class Car {

        private FloatBuffer mVertexBuffer;
        private float mVertices[] = { -0.1f, 0.1f, 0.1f, 0.1f, 0.1f, -0.1f, -0.1f, -0.1f };
        private ShortBuffer mDrawListBuffer;
        private final short DRAW_ORDER[] = { 0, 1, 2, 0, 2, 3 };
        private FloatBuffer mTextureCoordBuffer;
        private final float TEXTURE_COORDS[] = { 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f };

        private int mShader;
        private int mCarMoveDirection;

        private Bitmap mBackGroundImage;
        private float[] lanePosY = {0.28f, 0.0f, -0.28f, -0.56f};


        public Car(Bitmap image, int shader, int lane) {
            mBackGroundImage = image;
            mShader = shader;
            mCarMoveDirection = lane > 1 ? 1 : -1;

            float scaleX = (float) mBackGroundImage.getWidth() / (float) mBackGroundImage.getHeight() / mMainActivity.getRenderer().getSurfaceAspectRatio();

            mVertices[0] = (-1.5f + 0.1f) * mCarMoveDirection * scaleX;
            mVertices[2] = (-1.5f - 0.1f) * mCarMoveDirection * scaleX;
            mVertices[4] = (-1.5f - 0.1f) * mCarMoveDirection * scaleX;
            mVertices[6] = (-1.5f + 0.1f) * mCarMoveDirection * scaleX;

            mVertices[1] = lanePosY[lane] + 0.1f;
            mVertices[3] = lanePosY[lane] + 0.1f;
            mVertices[5] = lanePosY[lane] - 0.1f;
            mVertices[7] = lanePosY[lane] - 0.1f;

            ByteBuffer vb = ByteBuffer.allocateDirect(mVertices.length * 4);
            vb.order(ByteOrder.nativeOrder());
            mVertexBuffer = vb.asFloatBuffer();
            mVertexBuffer.put(mVertices);
            mVertexBuffer.position(0);

            ByteBuffer drawListBuffer = ByteBuffer.allocateDirect(DRAW_ORDER.length * 2);
            drawListBuffer.order(ByteOrder.nativeOrder());
            mDrawListBuffer = drawListBuffer.asShortBuffer();
            mDrawListBuffer.put(DRAW_ORDER);
            mDrawListBuffer.position(0);

            ByteBuffer textureCoordBuffer = ByteBuffer.allocateDirect(TEXTURE_COORDS.length * 4);
            textureCoordBuffer.order(ByteOrder.nativeOrder());
            mTextureCoordBuffer = textureCoordBuffer.asFloatBuffer();
            mTextureCoordBuffer.put(TEXTURE_COORDS);
            mTextureCoordBuffer.position(0);

            int texture = 0;
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

            mPositionHandle = GLES20.glGetAttribLocation(mShader, "vPosition");
            mTextureCoordHandle = GLES20.glGetAttribLocation(mShader, "vTextureCoord");
            GLES20.glEnableVertexAttribArray(mPositionHandle);
            GLES20.glEnableVertexAttribArray(mTextureCoordHandle);
            // Alpha-Blending aktivieren
            GLES20.glEnable(GLES20.GL_BLEND);
            // schwarze Bereiche als transparent darstellen
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        }

        public void move(float moveValue) {
            for(int vertexNumber = 0; vertexNumber < 8; vertexNumber += 2) {
                mVertices[vertexNumber] += moveValue * (float) mCarMoveDirection;
            }
            RectF frogBounds, carBounds;
            frogBounds = new RectF(mMainActivity.getRenderer().getFrog().getVertices()[6], mMainActivity.getRenderer().getFrog().getVertices()[7],
                    mMainActivity.getRenderer().getFrog().getVertices()[2], mMainActivity.getRenderer().getFrog().getVertices()[3]);

            if (mCarMoveDirection > 0) {
                carBounds = new RectF(mVertices[4], mVertices[5], mVertices[0], mVertices[1]);
            } else {
                carBounds = new RectF(mVertices[6], mVertices[7], mVertices[2], mVertices[3]);
            }

            if (RectF.intersects(frogBounds, carBounds)) {
                mMainActivity.getSoundPool().play(mMainActivity.getSoundId(1), 1.0f, 1.0f, 1, 0, 1.0f);
                if (mMainActivity.getRenderer().getLevel().getLifes() < 1) {
                    mMainActivity.getSurfaceView().setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
                    Intent intent = new Intent(MainActivity.ACTION_SHOW_DIALOG);
                    mMainActivity.sendBroadcast(intent);
                } else {
                    mMainActivity.getRenderer().getLevel().setLifes(mMainActivity.getRenderer().getLevel().getLifes() - 1);
                    float frogCenterY = frogBounds.bottom + (frogBounds.top - frogBounds.bottom) / 2;
                    mMainActivity.getRenderer().getFrog().move(-0.8f - frogCenterY - (mMainActivity.getRenderer().getFrog().getJumping() ? 0.07f : 0.0f));
                }
            }

        }

        public void draw() {
            GLES20.glUseProgram(mCarShader);
            mVertexBuffer.put(mVertices);
            mVertexBuffer.position(0);
            GLES20.glVertexAttribPointer(mPositionHandle, 2, GLES20.GL_FLOAT, false, 2 * 4, mVertexBuffer);
            GLES20.glVertexAttribPointer(mTextureCoordHandle, 2, GLES20.GL_FLOAT, false, 2 * 4, mTextureCoordBuffer);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, mBackGroundImage, 0);
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, DRAW_ORDER.length, GLES20.GL_UNSIGNED_SHORT, mDrawListBuffer);
        }

    }
}
