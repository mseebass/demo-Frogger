package com.example.michael.opengles20frogger;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.opengl.GLES20;
import android.opengl.GLUtils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;

/**
 * Created by Michael on 07.11.2014.
 */
public class Level {

    private MainActivity mMainActivity;
    private FloatBuffer mVertexBuffer;
    private static final float VERTICES[] = { -1.0f, 1.0f, 1.0f, 1.0f, 1.0f, -1.0f, -1.0f, -1.0f };
    private ShortBuffer mDrawListBuffer;
    private static final short DRAW_ORDER[] = { 0, 1, 2, 0, 2, 3 };
    private FloatBuffer mTextureCoordBuffer;
    private static final float TEXTURE_COORDS[] = { 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f };
    private int mLevelShader;

    private Bitmap mBackGroundImage;
    int mPositionHandle, mTextureCoordHandle;
    private int mLifes = 3;
    private float mLifeVertices[] = { -0.9f, 1.0f, -0.75f, 1.0f, -0.75f, 0.75f, -0.9f, 0.75f };
    private static final float LIFES_TEXTURE_COORDS[] = {
            0.66f, 0.0f,
            1.0f, 0.0f,
            1.0f, 1.0f,
            0.66f, 1.0f
    };

    private float mPointsVertices[] = { 0.3f, 0.96f, 1.0f, 0.96f, 1.0f, 0.84f, 0.3f, 0.84f };
    private float mPoints = 0;
    private Bitmap mPointsImage;
    private Canvas mPointsImageCanvas;
    private Paint mTextPaint;

    private static String sVertexShaderCode =
            "attribute vec4 vPosition;\n" +
                    "attribute vec2 vTextureCoord;\n" +
                    "varying vec2 fTextureCoord;\n" +
                    "void main() {\n" +
                    "gl_Position = vPosition;\n" +
                    "fTextureCoord = vTextureCoord;\n" +
                    "}\n";

    private static String sFragmentShaderCode =
            "precision mediump float;\n" +
                    "varying vec2 fTextureCoord;\n" +
                    "uniform sampler2D fTexture;\n" +
                    "void main() {\n" +
                    "gl_FragColor = texture2D(fTexture, fTextureCoord);\n" +
                    "}\n";


    public Level(MainActivity activity) {
        this.mMainActivity = activity;
    }

    public void onSurfaceCreated(EGLConfig eglConfig) {
        ByteBuffer vb = ByteBuffer.allocateDirect(VERTICES.length * 4);
        vb.order(ByteOrder.nativeOrder());
        mVertexBuffer = vb.asFloatBuffer();
        mVertexBuffer.put(VERTICES);
        mVertexBuffer.position(0);

        ByteBuffer drawListBuffer = ByteBuffer.allocateDirect(DRAW_ORDER.length * 2);
        drawListBuffer.order(ByteOrder.nativeOrder());
        mDrawListBuffer = drawListBuffer.asShortBuffer();
        mDrawListBuffer.put(DRAW_ORDER);
        mDrawListBuffer.position(0);

        ByteBuffer textureCoordBuffer = ByteBuffer.allocateDirect(TEXTURE_COORDS.length * 4);
        textureCoordBuffer.order(ByteOrder.nativeOrder());
        mTextureCoordBuffer = textureCoordBuffer.asFloatBuffer();
        mTextureCoordBuffer.put(TEXTURE_COORDS);
        mTextureCoordBuffer.position(0);

        int vertexShader = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);
        GLES20.glShaderSource(vertexShader, sVertexShaderCode);
        GLES20.glCompileShader(vertexShader);

        int fragmentShader = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);
        GLES20.glShaderSource(fragmentShader, sFragmentShaderCode);
        GLES20.glCompileShader(fragmentShader);

        mLevelShader = GLES20.glCreateProgram();
        GLES20.glAttachShader(mLevelShader, vertexShader);
        GLES20.glAttachShader(mLevelShader, fragmentShader);
        GLES20.glLinkProgram(mLevelShader);

        mBackGroundImage = BitmapFactory.decodeResource(mMainActivity.getResources(), R.drawable.world);
        int texture = 0;
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

        mPositionHandle = GLES20.glGetAttribLocation(mLevelShader, "vPosition");
        mTextureCoordHandle = GLES20.glGetAttribLocation(mLevelShader, "vTextureCoord");
        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glEnableVertexAttribArray(mTextureCoordHandle);

        // Textanzeige
        mPointsImage = Bitmap.createBitmap(256, 40, Bitmap.Config.ARGB_4444);
        mPointsImageCanvas = new Canvas(mPointsImage);
        mPointsImage.eraseColor(0);
        mTextPaint = new Paint();
        mTextPaint.setTextSize(40f);
        mTextPaint.setAntiAlias(true);
        mTextPaint.setARGB(255, 0, 255, 0);

        addPoints(0);
        int pointsTexture = 0;
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, pointsTexture);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
    }

    public void addPoints(float pointsToAdd) {
        mPoints += pointsToAdd;
        mPointsImage.eraseColor(0);
        mPointsImageCanvas.drawText("Punkte: " + String.valueOf((int) mPoints), 0, 38, mTextPaint);
    }

    public void setPoints(float points) {
        mPoints = points;
    }

    public void onSurfaceChanged(int width, int height) {
    }

    public void onDrawFrame() {
        GLES20.glUseProgram(mLevelShader);
        GLES20.glVertexAttribPointer(mPositionHandle, 2, GLES20.GL_FLOAT, false, 2 * 4, mVertexBuffer);
        GLES20.glVertexAttribPointer(mTextureCoordHandle, 2, GLES20.GL_FLOAT, false, 2 * 4, mTextureCoordBuffer);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, mBackGroundImage, 0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, DRAW_ORDER.length, GLES20.GL_UNSIGNED_SHORT, mDrawListBuffer);

        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0 , mMainActivity.getRenderer().getFrog().getImage(), 0);
        mVertexBuffer.put(mLifeVertices);
        mVertexBuffer.position(0);
        mTextureCoordBuffer.put(LIFES_TEXTURE_COORDS);
        mTextureCoordBuffer.position(0);

        for (int lifeCounter = 0; lifeCounter < mLifes; lifeCounter++) {
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, DRAW_ORDER.length, GLES20.GL_UNSIGNED_SHORT, mDrawListBuffer);
            for (int vertexNr = 0; vertexNr < 7; vertexNr += 2) {
                mLifeVertices[vertexNr] += 0.15f;
            }
            mVertexBuffer.put(mLifeVertices);
            mVertexBuffer.position(0);
        }

        for (int vertexNr = 0; vertexNr < 7; vertexNr += 2) {
            mLifeVertices[vertexNr] -= 0.15f * mLifes;
        }

        mTextureCoordBuffer.put(TEXTURE_COORDS);
        mTextureCoordBuffer.position(0);

        mVertexBuffer.put(mPointsVertices);
        mVertexBuffer.position(0);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0 ,mPointsImage, 0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, DRAW_ORDER.length, GLES20.GL_UNSIGNED_SHORT, mDrawListBuffer);

        mVertexBuffer.put(VERTICES);
        mVertexBuffer.position(0);
    }

    public int getLifes() {
        return mLifes;
    }

    public void setLifes(int lifes) {
        mLifes = lifes;
    }

    public float getPoints() {
        return mPoints;
    }
}