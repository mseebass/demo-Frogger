package com.example.michael.opengles20frogger;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLUtils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.Random;

import javax.microedition.khronos.egl.EGLConfig;

/**
 * Created by Michael on 07.11.2014.
 */
public class Frog {

    private MainActivity mMaintActivity;
    private FloatBuffer mVertexBuffer;
    private float mVertices[] = {-0.13f, 0.13f, 0.13f, 0.13f, 0.13f, -0.13f, -0.13f, -0.13f};
    private ShortBuffer mDrawListBuffer;
    private static final short DRAW_ORDER[] = {0, 1, 2, 0, 2, 3};
    private FloatBuffer mTextureCoordBuffer;
    private float mTextureCoords[] = {0.0f, 0.0f, 0.33f, 0.0f, 0.33f, 1.0f, 0.0f, 1.0f};
    private int mFrogShader;

    private Bitmap mFrogImage;
    int mPositionHandle, mTextureCoordHandle;
    private boolean mJumping = false;
    private Random mRandom = new Random();

    private static String sVertexShaderCode =
            "attribute vec4 vPosition;\n" +
                    "attribute vec2 vTextureCoord;\n" +
                    "varying vec2 fTextureCoord;\n" +
                    "void main() {\n" +
                    "gl_Position = vPosition;\n" +
                    "fTextureCoord = vTextureCoord;\n" +
                    "}\n";

    private static String sFragmentShaderCode =
            "precision mediump float;\n" +
                    "varying vec2 fTextureCoord;\n" +
                    "uniform sampler2D fTexture;\n" +
                    "void main() {\n" +
                    "gl_FragColor = texture2D(fTexture, fTextureCoord);\n" +
                    "}\n";


    public Frog(MainActivity activity) {
        this.mMaintActivity = activity;
    }

    public void onSurfaceCreated(EGLConfig eglConfig) {
        ByteBuffer vb = ByteBuffer.allocateDirect(mVertices.length * 4);
        vb.order(ByteOrder.nativeOrder());
        mVertexBuffer = vb.asFloatBuffer();
        mVertexBuffer.put(mVertices);
        mVertexBuffer.position(0);

        ByteBuffer drawListBuffer = ByteBuffer.allocateDirect(DRAW_ORDER.length * 2);
        drawListBuffer.order(ByteOrder.nativeOrder());
        mDrawListBuffer = drawListBuffer.asShortBuffer();
        mDrawListBuffer.put(DRAW_ORDER);
        mDrawListBuffer.position(0);

        ByteBuffer textureCoordBuffer = ByteBuffer.allocateDirect(mTextureCoords.length * 4);
        textureCoordBuffer.order(ByteOrder.nativeOrder());
        mTextureCoordBuffer = textureCoordBuffer.asFloatBuffer();
        mTextureCoordBuffer.put(mTextureCoords);
        mTextureCoordBuffer.position(0);

        int vertexShader = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);
        GLES20.glShaderSource(vertexShader, sVertexShaderCode);
        GLES20.glCompileShader(vertexShader);

        int fragmentShader = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);
        GLES20.glShaderSource(fragmentShader, sFragmentShaderCode);
        GLES20.glCompileShader(fragmentShader);

        mFrogShader = GLES20.glCreateProgram();
        GLES20.glAttachShader(mFrogShader, vertexShader);
        GLES20.glAttachShader(mFrogShader, fragmentShader);
        GLES20.glLinkProgram(mFrogShader);

        mFrogImage = BitmapFactory.decodeResource(mMaintActivity.getResources(), R.drawable.frog);
        int texture = 0;
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

        mPositionHandle = GLES20.glGetAttribLocation(mFrogShader, "vPosition");
        mTextureCoordHandle = GLES20.glGetAttribLocation(mFrogShader, "vTextureCoord");
        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glEnableVertexAttribArray(mTextureCoordHandle);
    }

    public void onSurfaceChanged(int width, int height) {
        mVertices[0] = -0.13f / mMaintActivity.getRenderer().getSurfaceAspectRatio();
        mVertices[2] = +0.13f / mMaintActivity.getRenderer().getSurfaceAspectRatio();
        mVertices[4] = +0.13f / mMaintActivity.getRenderer().getSurfaceAspectRatio();
        mVertices[6] = -0.13f / mMaintActivity.getRenderer().getSurfaceAspectRatio();
        move(-0.8f);
    }

    public void reset(){
        float frogCenter = mVertices[5] + (mVertices[1] - mVertices[5]) / 2;
        move(-0.8f - frogCenter - (mJumping ? 0.07f : 0f));
    }

    public void move(float moveValue) {
        if (mVertices[1] + moveValue > 0.7f) {
            mMaintActivity.getRenderer().getLevel().addPoints(1 * mMaintActivity.getRenderer().getCars().getSpeed() * mMaintActivity.getRenderer().getCars().getSpeed());
            mMaintActivity.getRenderer().getCars().setSpeed(mMaintActivity.getRenderer().getCars().getSpeed() + 0.1f);
            float frogCenter = mVertices[5] + (mVertices[1] - mVertices[5]) / 2;
            moveValue = -0.8f - frogCenter - (mJumping ? 0.07f : 0f);
            float oldFrogCenterX = mVertices[0] + ((mVertices[2] - mVertices[0]) / 2);
            float newFrogCenterX = -0.85f + ((float) mRandom.nextInt(7) * 0.29f);
            for (int vertexNr = 0; vertexNr < 7; vertexNr += 2) {
                mVertices[vertexNr] += newFrogCenterX - oldFrogCenterX;
            }
        }
        for (int vertexNr = 1; vertexNr < 8; vertexNr += 2) {
            mVertices[vertexNr] += moveValue;
        }
        mVertexBuffer.put(mVertices);
        mVertexBuffer.position(0);
    }

    public void setImage(int imageNr) {
        mTextureCoords[0] = (float) imageNr * 0.33f;
        mTextureCoords[2] = (float) (imageNr + 1) * 0.33f;
        mTextureCoords[4] = (float) (imageNr + 1) * 0.33f;
        mTextureCoords[6] = (float) imageNr * 0.33f;
        mTextureCoordBuffer.put(mTextureCoords);
        mTextureCoordBuffer.position(0);
    }

    public Bitmap getImage() {
        return mFrogImage;
    }

    public void onDrawFrame() {
        GLES20.glUseProgram(mFrogShader);
        GLES20.glVertexAttribPointer(mPositionHandle, 2, GLES20.GL_FLOAT, false, 2 * 4, mVertexBuffer);
        GLES20.glVertexAttribPointer(mTextureCoordHandle, 2, GLES20.GL_FLOAT, false, 2 * 4, mTextureCoordBuffer);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, mFrogImage, 0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, DRAW_ORDER.length, GLES20.GL_UNSIGNED_SHORT, mDrawListBuffer);
    }


    public void setJumping(boolean jumping) {
        this.mJumping = jumping;
    }

    public float[] getVertices() {
        return mVertices;
    }

    public boolean getJumping() {
        return mJumping;
    }
}